Arquivo zip gerado em: 22/09/2023 17:08:22 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [3 - Repetição] Astronauta confuso